import MainHeader from "./components/MainHeader";
import Meals from "./components/Meals";
import FoodOrderProvider from "./store/food-order-context";
import { UserProgressContextProvider } from "./store/UserProgressContext";

function App() {
  return (
    <UserProgressContextProvider>
      <FoodOrderProvider>
        <MainHeader />
        <Meals />
      </FoodOrderProvider>
    </UserProgressContextProvider>
  );
}

export default App;
